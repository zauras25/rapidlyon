RapidlyOn safe QA patch
1. Copy Apply-RapidlyOn-QA-Fixes.ps1 to C:\Users\M.Zohaib\Desktop\rapidlyon-clean\
2. Copy qa-fix-verification.mjs to rapidlyon-clean\scripts\
3. In VS Code PowerShell: powershell -NoProfile -ExecutionPolicy Bypass -File .\Apply-RapidlyOn-QA-Fixes.ps1
4. Browser test requires an already running production server at localhost:3000. If not started, run npm run start -- -p 3000 in a separate terminal and node scripts/qa-fix-verification.mjs in main terminal.
5. Review screenshots + selector-level small-target report at qa-artifacts/qa-fixes/index.html.
No database migrations, production changes, Git commits, or GitHub pushes are executed by this patch.
