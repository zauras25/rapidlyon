import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { PublicShell } from '@/components/site/chrome';
export default function NotFound(){return <PublicShell><main><div className="shell" style={{minHeight:'65vh',display:'flex',flexDirection:'column',justifyContent:'center',alignItems:'flex-start',paddingBlock:80}}><p className="eyebrow">404 / Page not found</p><h1 style={{fontSize:'clamp(3.5rem,8vw,7rem)'}}>This isn&apos;t the<br/><span style={{color:'#7eaf28'}}>end of the road.</span></h1><p className="lead" style={{marginTop:28}}>The page you&apos;re looking for may have moved. Let&apos;s get you back to something good.</p><Link href="/" className="btn btn-dark" style={{marginTop:20}}><ArrowLeft size={17}/> Back to homepage</Link></div></main></PublicShell>}
